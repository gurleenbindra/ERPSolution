<?php

//import.php

require_once ('vendor/autoload.php');
use PhpOffice\PhpSpreadsheet\IOFactory;
use PhpOffice\PhpSpreadsheet\Spreadsheet;
include 'data2.php';
//$connect = new PDO("mysql:host=localhost;dbname=example", "root", "");

if($_FILES["import_excel"]["name"] != '')
{
 $allowed_extension = array('xls', 'csv', 'xlsx');
 $file_array = explode(".", $_FILES["import_excel"]["name"]);
 $file_extension = end($file_array);

 if(in_array($file_extension, $allowed_extension))
 {
  $file_name = time() . '.' . $file_extension;
  move_uploaded_file($_FILES['import_excel']['tmp_name'], $file_name);
  //$spreadsheet = new PhpOffice\PhpSpreadsheet();
  $file_type =\PhpOffice\PhpSpreadsheet\IOFactory::identify($file_name);
  $reader = IOFactory::createReader($file_type);

  $spreadsheet = $reader->load($file_name);

  unlink($file_name);

  $data = $spreadsheet->getActiveSheet()->toArray();

  foreach($data as $row)
  {
   $insert_data = array(
    ':name'  => $row[0],
    ':address'  => $row[1],
    ':phoneno'  => $row[2],
     ':leasedate'  => $row[3],
    ':enddate'  => $row[4],
    ':equipment'  => $row[5],
    ':rent'  => $row[6],
    ':sec'  => $row[7]
   
   );

    $sql = "INSERT INTO test2 (name,address,phoneno,leasedate,enddate,equipment,rent,sec) VALUES (:name,:address,:phoneno,:leasedate,:enddate,:equipment,:rent,:sec)";
   $statement=$pdo->prepare($sql);
   $statement->execute($insert_data);
  }
  $message = '<div class="alert alert-success">Data Imported Successfully</div>';

 }
 else
 {
  $message = '<div class="alert alert-danger">Only .xls .csv or .xlsx file allowed</div>';
 }
}
else
{
 $message = '<div class="alert alert-danger">Please Select File</div>';
}

echo $message;

?>
