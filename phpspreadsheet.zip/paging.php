<?php
include 'data1.php';
session_start();
?><!DOCTYPE html>
<html>
<head>
	<title>CUSTOMER DETAILS</title>
	<!--<link href="com.css" rel="stylesheet">-->
	<meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
 	 <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
 	 <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>
	<!--<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">-->
	
	<!--<a href="w1.php">Insert Data</a>-->
	
</head>
<body>
	<nav class="navbar navbar-inverse">
  <div class="container-fluid">
    <div class="navbar-header">
      <li class="navbar-brand" href="#">Admin &nbsp;&nbsp;</li>
    </div>
   <ul class="nav navbar-nav">
      <li ><a href="home.php">Home</a></li>
      <li class="active"><a href="paging.php">View Data</a></li>
      <li><a href="w1.php">Insert</a></li>
      <li><a href="mail2.php">Email</a></li>
      <li><a href="sortform.php">Sort</a></li>
      <li><a href="extest.php">Import</a></li>
      <li><a href="sql_to_excel.php">Export</a></li>
    </ul>
    <ul class="nav navbar-nav navbar-right">
      <!--<li><a href="#"><span class="glyphicon glyphicon-user"></span> Sign Up</a></li>-->
      <li><a href="#"><span class="glyphicon glyphicon-log-in"></span> Login</a></li>
    </ul>
  </div>
</nav>
<form name="sort" action="sort1.php" method="post"> 
<select name="order"><!--Dropdown for sorting-->
   <option value="id">ID</option>
   <option value="name">Name</option>
   <option value="equipment">Equipment</option>
   <option value="address">Address</option>
   <option value="phoneno">PhoneNo.</option>
   <option value="leasedate">Lease Date</option>
   <option value="enddate">End Date</option>
   <option value="period">Period of Hire</option>
   <option value="rent">Rent</option>

</select>
<input type="submit" name="sub" value=" - Sort - " />
</form>
<h2 style="text-align: center"><u>CUSTOMER DETAILS</u></h2>
	<?php
	//define how many results per page
	$results_per_page=3;
	//find out the number of results stored in db
	//$sql="SELECT * FROM leaserecords";
	$number_of_results = $pdo->query('select count(*) from leaserecords')->fetchColumn();

	//determine total number of pages available
	$number_of_pages=ceil($number_of_results/$results_per_page);
	//determine on which page visitor is currently on
	if (!isset($_GET['page'])) 
	{
		$page=1;
	}
	else
	{
		$page=$_GET['page'];
	}
	//determine the sql LIMIT starting number for the results on the displaying page
	$this_page_first_result=($page-1)*$results_per_page;


	//display the links to the page
	for($page=1;$page<=$number_of_pages;$page++)
	{
		if($page==1)
		{?>
			<a href="paging.php?page=<?php echo $page;?>" class="btn btn-primary btn-lg active" role="button">First</a>;
		<?php 
		}
		elseif ($page==$number_of_pages)
		 {
			# code...?>
			<a href="paging.php?page=<?php echo $page;?>" class="btn btn-primary btn-lg active" role="button">Last</a>;
			<?php
		}
		else
		{		
			?>

		<a href="paging.php?page=<?php echo $page;?>" class="btn btn-primary btn-lg active" role="button"><?php echo $page; ?></a>;
	<?php }
	}

	?>
<table class="table table-striped table-hover">
	<thead>
		<th><h3>S.No.</h3></th>
		<!--<th><h3>USERNAME</h3></th>-->
		<th><h3>DATE LEASED</h3></th>
		<th><h3>CUSTOMER'S NAME</h3></th>
		<th><h3>ADDRESS</h3></th>
		<th><h3>PHONE</h3></th>
		<th><h3>LEASING DATE</h3></th>
		<th><h3>END DATE</h3></th>
		<th><h3>EQUIPMENT LEASED</h3></th>
		<th><h3>PERIOD OF HIRE</h3></th>
		<th><h3>RENT</h3></th>
		<th><h3>SECURITY</h3></th>
		<th><h3>CARRIAGE</h3></th>
		<th><h3>COMMENTS</h3></th>
		<th><h3>EMAIL</h3></th>
		<th><h3>DATE PICKED</h3></th>


	</thead>
	<tbody>

		<?php					
				$a=1;
				$sql="SELECT * FROM leaserecords LIMIT $this_page_first_result, $results_per_page";
				$stmt=$pdo->prepare($sql);
				$stmt->execute();
				$data=$stmt->fetchAll();
		// print_r($data);
				foreach ($data as $k)
				 {
						?>
						<tr>
							<td><?php echo $a;?></td>
							<!--<td><?php// echo $k['username'];?></td>-->
							<td><?php echo $k['dateleased'];?></td>
							<td><?php echo $k['name'];?></td>
							<td><?php echo $k['address'];?></td>
							<td><?php echo $k['phoneno'];?></td>
							<td><?php echo $k['leasedate'];?></td>
							<td><?php echo $k['enddate'];?></td>
							<td><?php echo $k['equipment'];?></td>
							<td><?php echo $k['period'];?></td>
							<td><?php echo $k['rent'];?></td>
							<td><?php echo $k['sec'];?></td>
							<td><?php echo $k['carriage'];?></td>
							<td><?php echo $k['comments'];?></td>
							<td><?php echo $k['email'];?></td>
							<td><?php echo $k['datepicked'];?></td>

							<td>
      							<a href="editnew.php?id=<?php echo $k['id'];?>" class="btn btn-primary btn-lg active" role="button">EDIT</a>
    						</td>
    						<td>
      							<a href="form.php?id=<?php echo $k['id'];?>" class="btn btn-primary btn-lg active" role="button">CREATE LEASE LETTER</a>
							</td>
						</tr>
						<?php $a++; 
				}
	 ?>
	</tbody>
</table>
 <!--<ul class="pagination">
        <li><a href="?page=1">First</a></li>
        <li class="<?php if($page <= 1){ echo 'disabled'; } ?>">
            <a href="<?php if($page < 1){ echo '#'; } else { echo "?page=".($page - 1); } ?>">Prev</a>
        </li>
        <li class="<?php if($page >= $number_of_pages){ echo 'disabled'; } ?>">
            <a href="<?php if($page >= $number_of_pages){ echo '#'; } else { echo "?page=".($page + 1); } ?>">Next</a>
        </li>
        <li><a href="?page=<?php echo $number_of_pages; ?>">Last</a></li>
    </ul>-->
</body>
</html> 