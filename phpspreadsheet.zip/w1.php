<!DOCTYPE HTML> 
<html lang="en">
<head>
<title>Form></title>

<meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
  <link href="com.css" rel="stylesheet">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>
<?php 
include 'data1.php';
?>
</head>
<body>
  <nav class="navbar navbar-inverse">
  <div class="container-fluid">
    <div class="navbar-header">
      <li class="navbar-brand" href="#">Admin &nbsp;&nbsp;</li>
    </div>
   <ul class="nav navbar-nav">
      <li ><a href="home.php">Home</a></li>
      <li><a href="paging.php">View Data</a></li>
      <li class="active"><a href="w1.php">Insert</a></li>
      <li><a href="mail2.php">Email</a></li>
      <li><a href="sortform.php">Sort</a></li>
      <li><a href="extest.php">Import</a></li>
      <li><a href="sql_to_excel.php">Export</a></li>
    </ul>
    <ul class="nav navbar-nav navbar-right">
      <!--<li><a href="#"><span class="glyphicon glyphicon-user"></span> Sign Up</a></li>-->
      <li><a href="#"><span class="glyphicon glyphicon-log-in"></span> Login</a></li>
    </ul>
  </div>
</nav>
<div align="center">
  <h3>Insert the values below: </h3>
<form method="post" action="insert2.php" id="f1">
<table>
  <tr>
  <td>Name:</td>
  <td><input type="text" id="name" name="name" required>
  </td>
</tr>
<!--<tr>
  <td>Username:</td>
  <td><input type="text" id="username" name="username" minlength="8" required>
  </td>
</tr>-->
<tr>
  <td>Address:</td>
  <td><input type="text" id="add" name="add" required>
  </td>
</tr>
<tr>
  <td>Phone No.:</td>
  <td><input type="text" id="phoneno" name="phoneno" placeholder="1234567890" required>
  </td>
</tr>
<tr>
  <td>Equipment Leased:</td>
  <td><input type="text" id="equipment" name="equipment" required>
  </td>
</tr>
<tr>
<td>Leasing Date:</td>
<td><input type="date"name="leasedate" id="leasedate" required></td>
</tr>
<!--<tr>
<td>Date Leased:</td>
<td><input type="date" value="<?php //echo date("Y-m-d"); ?>" required></td>
</tr>-->
<tr>
<td>End Date:</td>
<td><input type="date"name="enddate" id="enddate" required></td>
</tr>
<tr>
<td>Period of Hire</td>
<td><input type="text" name="period" id="period" placeholder="6 weeks" required></td>
</tr>
<tr>
<td>Rent(Incl. of Taxes):</td>
<td><input type="text" name="rent" id="rent" placeholder="6500" required></td>
</tr>
<tr>
<td>Security Charge:</td>
<td><input type="text" name="sec" id="sec" placeholder="6500" ></td>
</tr>
<tr>
<td>Carriage:</td>
<td><input type="text" name="carriage" id="carriage" placeholder="500" ></td>
</tr>
<tr>
<td><input type="submit" name="sub" value="submit"></td>
</tr>
</table>
</form>
</div>
</body>
</html>
