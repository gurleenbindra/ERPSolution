<?php

//html-to-excel.php
include 'data2.php';
//$connect = new PDO("mysql:host=localhost;dbname=testing", "root", "");

$query = "SELECT * FROM test";

$statement =$pdo->prepare($query);

$statement->execute();

$result = $statement->fetchAll();

?>

<!DOCTYPE html>
<html>
   <head>
     <title>Convert HTML Table to Excel using PHPSpreadsheet</title>
     <meta name="viewport" content="width=device-width, initial-scale=1.0">
     <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/css/bootstrap.min.css" />
     <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>
   </head>
   <body>
    <nav class="navbar navbar-inverse">
  <div class="container-fluid">
    <div class="navbar-header">
      <li class="navbar-brand">Admin &nbsp;&nbsp;</li>
    </div>
    <ul class="nav navbar-nav">
      <li><a href="home.php">Home</a></li>
      <li><a href="paging.php">View Data</a></li>
      <li><a href="w1.php">Insert</a></li>
      <li><a href="mail2.php">Email</a></li>
      <li><a href="sortform.php">Sort</a></li>
      <li><a href="extest.php">Import</a></li>
      <li ><a href="sql_to_excel.php">Export</a></li>
      <li class="active"><a href="export1.php">Export</a></li>
    </ul>
    <ul class="nav navbar-nav navbar-right">
      <!--<li><a href="#"><span class="glyphicon glyphicon-user"></span> Sign Up</a></li>-->
      <li><a href="#"><span class="glyphicon glyphicon-log-in"></span> Login</a></li>
    </ul>
  </div>
</nav>
     <div class="container">
      <br />
      <h3 align="center">Convert HTML Table to Excel using PHPSpreadsheet</h3>
      <br />
      <div class="table-responsive">
       <form method="POST" id="convert_form" action="export2.php">
            <table class="table table-striped table-bordered" id="table_content">
              <tr>
                <th><h3>S.No.</h3></th>
                <th><h3>CUSTOMERS NAME</h3></th>
                <th><h3>ADDRESS</h3></th>
                <th><h3>PHONE</h3></th>
                <th><h3>LEASING DATE</h3></th>
                <th><h3>END DATE</h3></th>
                <th><h3>EQUIPMENT LEASED</h3></th>
                <th><h3>RENT</h3></th>
                <th><h3>SEC</h3></th>
              </tr>
              <?php
              foreach($result as $k)
              {
                echo '
                <tr>
                  <td>'.$k['id'] .'</td>
                  <td>'. $k['name'].'</td>
                  <td>'.$k['address'].'</td>
                  <td>'. $k['phoneno'].'</td>
                  <td>'.$k['leasedate'] .'</td>
                  <td>'.$k['enddate'].'</td>
                  <td>'. $k['equipment'].'</td>
                  <td>'.$k['rent'].'</td>
                  <td>'. $k['sec'].'</td>           
                </tr>
                ';
              }
              ?>
            </table>
            <input type="hidden" name="file_content" id="file_content" />
            <button type="button" name="convert" id="convert" class="btn btn-primary">Convert</button>
          </form>
          <br />
          <br />
      </div>
     </div>
     <script src="https://ajax.googleapis.com/ajax/libs/jquery/2.2.0/jquery.min.js"></script>
  </body>
</html>

<script>
$(document).ready(function(){
 $('#convert').click(function(){
    var table_content = '<table>';
    table_content += $('#table_content').html();
    table_content += '</table>';
    $('#file_content').val(table_content);
    $('#convert_form').submit();
  });
});
</script>
