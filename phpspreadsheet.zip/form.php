<!DOCTYPE HTML> 
<html>
<head>
<title>LETTER></title>
<?php
include 'data1.php';
session_start();?>
<meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>
<link href="com.css" rel="stylesheet">
</head>
<body>
    <nav class="navbar navbar-inverse">
  <div class="container-fluid">
    <div class="navbar-header">
     <li class="navbar-brand" href="#">Admin &nbsp;&nbsp;</li>
    </div>
    <ul class="nav navbar-nav">
      <li><a href="home.php">Home</a></li>
      <li class="active"><a href="paging.php">View Data</a></li>
      <li><a href="w1.php">Insert</a></li>
      <li><a href="mail2.php">Email</a></li>
      <li><a href="sortform.php">Sort</a></li>
      <li><a href="extest.php">Import</a></li>
      <li><a href="sql_to_excel.php">Export</a></li>
    </ul>
    <ul class="nav navbar-nav navbar-right">
      <!--<li><a href="#"><span class="glyphicon glyphicon-user"></span> Sign Up</a></li>-->
      <li><a href="#"><span class="glyphicon glyphicon-log-in"></span> Login</a></li>
    </ul>
  </div>
</nav>


<div id="source-html">
  <?php
    $id=$_GET['id'];
    $sql='SELECT * FROM  leaserecords where id=?';
    $stmt=$pdo->prepare($sql);
    $stmt->execute([$id]);
    $k1=$stmt->fetchAll();
    foreach($k1 as $g)
    {

    }

  ?>
  <h2 style="text-align: center;"><u>Leasing Rental Letter</u></h2>
  <p>GARGS IMPORTERS AND TRADERS LLP &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Ph:124-4113617</p>
  <p>#206,Style Plaza,Near Reliance Fresh,&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;M.9871482091</p>
  <p>Jharsa Road,Sec 15 Part 1,Gurgaon-122001&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;inhousegym@gmail.com</p>
  <p><b>"Wedeliver Health"</b></p>
  <p><b>TIN: 06811940625 GSTIN: 06AALFG4137D1ZN</b></p>
    <hr>
    <br>
    <br>
    <p><b>Sub:</b>Leasing Of Equipment.</p>
    <br>
    <table id="t1" cellspacing="0" border="1px solid #303030">
      <tr border="1px solid #303030">
        <td border="1px solid #303030">Leasing Date </td>
        <td border="1px solid #303030" style="color: green"><b><?php echo $g['leasedate'];?></b></td>
      </tr>
      <tr>
        <td>Equipment Leased&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</td>
        <td style="color: green"><b><?php echo $g['equipment'];?></b></td>
      </tr>
      <tr>
        <td>Leased To&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</td>
        <td style="color: green"><b><?php echo $g['name'];?></b>, <b><?php echo $g['address'];?></b>. <br><b>PhNo.<?php echo $g['phoneno'];?></b></td>
      </tr>
      <tr>
        <td>Period of Hire</td>
        <td style="color: green"><b><?php echo $g['period'];?></b>&nbsp; <b><?php echo $g['leasedate'];?></b> to <b><?php echo $g['enddate'];?></b></td>
      </tr>
      <tr>
        <td>Rent(Inclusive of Taxes)&nbsp;&nbsp;&nbsp;</td>
        <td style="color: green"><b>Rs. <?php echo $g['rent'];?>/-</b></td>
      </tr>
      <tr>
        <td>Security(refundable on return of m/c only)&nbsp;</td>
        <td style="color: green"><b>Rs. 2000/-</b></td>
      </tr>
      <tr>
        <td>Carriages charges&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</td>
        <td style="color: green"><b>Rs. 400/- Delivery 400/- pick up</b></td>
      </tr>
    </table>
    <hr>
    <p>Other terms and conditions as agreed to thru mail.</p>
    <p style="text-align: right;"><b>(P.C Garg)<br>Designated Partner</b></p>
    </div>
    <div class="content-footer">
    <button id="btn-export" onclick="exportHTML();">Click to download</button>
</div>
<script>
  
    function exportHTML(){
       var header = "<html xmlns:o='urn:schemas-microsoft-com:office:office' "+
            "xmlns:w='urn:schemas-microsoft-com:office:word' "+
            "xmlns='http://www.w3.org/TR/REC-html40'>"+
            "<head><meta charset='utf-8'><link href='com.css' rel='stylesheet'><title>Export HTML to Word Document with JavaScript</title></head><body>";
       var footer = "</body></html>";
       var sourceHTML = header+document.getElementById("source-html").innerHTML+footer;
       
       var source = 'data:application/vnd.ms-word;charset=utf-8,' + encodeURIComponent(sourceHTML);
       var fileDownload = document.createElement("a");
       document.body.appendChild(fileDownload);
       fileDownload.href = source;
       fileDownload.download = 'document.doc';
       fileDownload.click();
       document.body.removeChild(fileDownload);
    }
</script>
  </body>
  </html>