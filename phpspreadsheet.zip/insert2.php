<!DOCTYPE html>
<html lang="en">
<head>
  <title>Insert</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>
</head>
<body>

<nav class="navbar navbar-inverse">
  <div class="container-fluid">
    <div class="navbar-header">
      <li class="navbar-brand">Admin &nbsp;&nbsp;</li>
    </div>
    <ul class="nav navbar-nav">
      <li ><a href="phpspreadsheet/home.php">Home</a></li>
      <li><a href="paging.php">View Data</a></li>
      <li class="active"><a href="w1.php">Insert</a></li>
      <li><a href="mail2.php">Email</a></li>
      <li><a href="sortform.php">Sort</a></li>
      <li><a href="extest.php">Import</a></li>
      <li><a href="sql_to_excel.php">Export</a></li>
    </ul>
    <ul class="nav navbar-nav navbar-right">
      <!--<li><a href="#"><span class="glyphicon glyphicon-user"></span> Sign Up</a></li>-->
      <li><a href="#"><span class="glyphicon glyphicon-log-in"></span> Login</a></li>
    </ul>
  </div>
</nav>


<?php
include 'data1.php';
 // $username=$_POST['username'];
  $name=$_POST['name'];
    $address=$_POST['add'];
    $phone=$_POST['phoneno'];
    $leasingdate=$_POST['leasedate'];
    $enddate=$_POST['enddate'];
   // $dateleased = date('Y-m-d', strtotime($_POST['dateFrom']));
    $equipmentleased=$_POST['equipment'];
    $periodofhire=$_POST['period'];
    $rent=$_POST['rent'];
    $sec=$_POST['sec'];
    $carriage=$_POST['carriage'];
    /*$sql1='SELECT id FROM leaserecords where username=?';
  $stmt1=$pdo->prepare($sql1);
  $stmt1->execute([$username]);
  $data=$stmt1->fetchAll();
  if(!$data)
  {*/
    $sql = "INSERT INTO leaserecords (name,address,phoneno,leasedate,enddate,equipment,period,rent,sec,carriage,dateleased) VALUES (:name,:address,:phoneno,:leasedate,:enddate,:equipment,:period,:rent,:sec,:carriage,:dateleased)";
   $stmt=$pdo->prepare($sql);
   $stmt->execute([':name'=>$name,':address'=>$address,':phoneno'=>$phone,':leasedate'=>$leasingdate,':enddate'=>$enddate,':equipment'=>$equipmentleased,':period'=>$periodofhire,':rent'=>$rent,':sec'=>$sec,':carriage'=>$carriage,':dateleased'=>$leasingdate]);
   echo "REGISTERED SUCCESSFULLY";

 /*}
 else
 {
  echo "USERNAME EXISTS";
  ?>
  <button><a href="w1.php">FILL FORM</a></button>
 <?php }*/
?>
<br>
<br>
<!--<button><a href="paging.php">View Data</a></button>-->

</body>
</html>