<!DOCTYPE HTML> 
<html>
<head>
<title>LETTER></title>
<?php
include 'data1.php';
session_start();?>
<meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>
<link href="com.css" rel="stylesheet">
<style>
.alert {
  padding: 20px;
  background-color: #008000;
  color: white;
}

.closebtn {
  margin-left: 15px;
  color: white;
  font-weight: bold;
  float: right;
  font-size: 22px;
  line-height: 20px;
  cursor: pointer;
  transition: 0.3s;
}

.closebtn:hover {
  color: black;
}
</style>

</head>
<body>

    <nav class="navbar navbar-inverse">
  <div class="container-fluid">
    <div class="navbar-header">
      <li class="navbar-brand" href="#">Admin &nbsp;&nbsp;</li>
    </div>
    <ul class="nav navbar-nav">
      <li ><a href="home.php">Home</a></li>
      <li class="active"><a href="paging.php">View Data</a></li>
      <li><a href="w1.php">Insert</a></li>
      <li><a href="mail2.php">Email</a></li>
      <li><a href="sortform.php">Sort</a></li>
      <li><a href="extest.php">Import</a></li>
      <li><a href="sql_to_excel.php">Export</a></li>
    </ul>
    <ul class="nav navbar-nav navbar-right">
      <!--<li><a href="#"><span class="glyphicon glyphicon-user"></span> Sign Up</a></li>-->
      <li><a href="#"><span class="glyphicon glyphicon-log-in"></span> Login</a></li>
    </ul>
  </div>
</nav>
<div align="center">
  <?php
    $id=$_GET['id'];
    $sql='SELECT * FROM  leaserecords where id=?';
    $stmt=$pdo->prepare($sql);
    $stmt->execute([$id]);
    $k1=$stmt->fetchAll();
    foreach($k1 as $g)
    {

    }
    echo "<form method='post' action='' id='f1'>";
   if (!isset($_POST['sub'])) {
echo " ";
  echo	"Name:<input type='text' id='name' name='name' value='". $g['name'] ."'><br /><br />";
  echo "Address:<input type='text' id='add' name='add' value='". $g['address'] ."'><br /><br />";
 echo "Phone No:<input type='text' id='phoneno' name='phoneno' value='". $g['phoneno'] ."'><br /><br />";
 echo "Equipment Leased:<input type='text' id='equipment' name='equipment' value='". $g['equipment'] ."'><br /><br />";
  echo "Leasing Date:<input type='date'name='leasedate' id='leasedate' value='". $g['leasedate'] ."'><br /><br />";
echo "End Date:<input type='date'name='enddate' id='enddate' value='". $g['enddate'] ."'><br /><br />";
echo "Period of Hire<input type='text' name='period' id='period' value='". $g['period'] ."'><br /><br />";
echo "Rent(Incl. of Taxes):<input type='text' name='rent' id='rent' value='". $g['rent'] ."'><br /><br />";
echo "Security:<input type='text' name='sec' id='sec' value='". $g['sec'] ."'><br /><br />";
echo "Carriage:<input type='text' name='carriage' id='carriage' value='". $g['carriage'] ."'><br /><br />";
echo "<input type='submit' name='sub' value='UPDATION'>";
//echo "<a href='display.php'>VIEW DATA</a>";
} echo "</form>";?></div>

<?php if (isset($_POST['sub'])) 
 {
 	$name=$_POST['name'];
    $address=$_POST['add'];
    $phone=$_POST['phoneno'];
    $leasingdate=$_POST['leasedate'];
    $enddate=$_POST['enddate'];
    $equipmentleased=$_POST['equipment'];
    $periodofhire=$_POST['period'];
    $rent=$_POST['rent'];
    $sql='UPDATE leaserecords Set name =?,
    	address=?,
    	phoneno=?,
    	leasedate=?,
    	enddate=?,
    	equipment=?,
    	period=?,
    	rent= ?
 WHERE id= ?';
 $stmt= $pdo->prepare($sql);
 $stmt->execute([$name, $address,$phone,$leasingdate,$enddate,$equipmentleased,$periodofhire,$rent ,$id]);
?>
<div class="alert">
  <span class="closebtn" onclick="this.parentElement.style.display='none';">&times;</span> 
  <strong>Success!</strong> Value updated.
</div>

<!--<a href="paging.php">VIEW DATA</a>-->

<?php }?>
</body>
</html>
